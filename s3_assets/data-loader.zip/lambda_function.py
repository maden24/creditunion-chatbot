import boto3
import csv
import io
import os

# Initialize AWS clients
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

# Define your S3 bucket name 
BUCKET_NAME = 'creditunionbot'


#Return csv file from S3 as string
def download_csv_from_s3(bucket_name, file_key):

    s3_object = s3.get_object(Bucket=bucket_name, Key=file_key)
    csv_content = s3_object['Body'].read().decode('utf-8')
    return csv_content
    
#Insert data into DynamoDB table
def insert_into_dynamodb(table_name, data, headers):
    table = dynamodb.Table(table_name)
    with table.batch_writer() as batch:
        for row in data:
            # Create a dictionary for the item to insert
            item = {headers[i]: row[i] for i in range(len(headers))}
            batch.put_item(Item=item)

def lambda_handler(event, context):
    #Load Environemnt Variables
    CSV_FILE_KEY = [os.environ['TABLE1_S3'],os.environ['TABLE2_S3']]
    TABLE_NAME = [os.environ['TABLE1_DYNAMODB'],os.environ['TABLE2_DYNAMODB']]
    for i in range(len(CSV_FILE_KEY)):
        # Download CSV from S3
        csv_content = download_csv_from_s3(BUCKET_NAME, CSV_FILE_KEY[i])

        # Read CSV content
        reader = csv.reader(io.StringIO(csv_content))
    
        # Extract headers
        headers = next(reader)
    
        # Read the rest of the rows
        data = list(reader)

        # Insert data into DynamoDB
        insert_into_dynamodb(TABLE_NAME[i], data, headers)




