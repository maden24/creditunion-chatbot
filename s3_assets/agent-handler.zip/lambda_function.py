import os
import json

import boto3
from boto3.dynamodb.conditions import Key
from langchain_community.chat_models import BedrockChat
from langchain.chains import ConversationChain
from decimal import Decimal

from agent import Agent
from chat import Chat

boto3_session = boto3.Session(region_name='us-east-1')
bedrock_client = boto3_session.client(service_name="bedrock-runtime")
dynamodb = boto3.resource('dynamodb',region_name='us-east-1')


dynamodb_tables=[os.environ['LOANS_TABLE'], os.environ['ACCOUNTS_TABLE']]




#Convert Decimal values to string
def convert_decimals(item):
    if isinstance(item, dict):
        return {k: convert_decimals(v) for k, v in item.items()}
    elif isinstance(item, list):
        return [convert_decimals(i) for i in item]
    elif isinstance(item, Decimal):
        return str(item)  # Convert Decimal to string
    return item

#Verify identity, return customer data
def verify_identity(username, pin):
    print('Verify identity called')
    #Parameters based on userID
    params = {
        'KeyConditionExpression': 'userID = :userID',
        'ExpressionAttributeValues': {
            ':userID': username  # Map username to userID
        }
    }

    items=[]
    
    try:
        for table_name in dynamodb_tables:
   
            table = dynamodb.Table(table_name)
            
            #Query dynamo db table based on parameters
            response = table.query(**params)
            table_items = response.get('Items', [])
            
            items+=table_items
    except Exception as e:
        print(f"Error querying table {table_name}: {e}")
 
    return convert_decimals(items)
    
    
    
#Validate identity slots
def validate_identity_slots(slots):
    print('Validate identity called', slots)
    if not slots['Username']:
        print ('Validating Username slot')
        return{
            'isValid': False,
            'invalidSlot': 'Username'
        }
        
    if not slots['Pin']:
        print ('Validating Pin slot')
        return{
            'isValid': False,
            'invalidSlot': 'Pin'
        }
    
    #Verify identity
    if slots['Pin'] and slots['Username']:
        items=verify_identity(slots['Username']['value']['interpretedValue'], slots['Pin']['value']['interpretedValue'])
     
        if not items:
            return {
                'isValid': False,
                'invalidSlot': 'Username',
                'message': 'Username and/or Pin is invalid. Please re-enter username and pin.'
            }
        else:
            # Return customer data as part of the response
            print('Customer Data', items)
            return {
                'isValid': True,
                'customerData': items
            }
    
            
#Invoke bedrock powered langchain agent with user input that calls Agent.invokellm_personal
def invoke_agent_personal(prompt, sessionId, customer_data):
    print('Invoke agent personal invoked')
    #Create chat and send User Message
    chat=Chat({'Human': prompt}, sessionId)
    
    #Create LLM and Agent object
    llm=BedrockChat(
        client=bedrock_client, 
        model_id="anthropic.claude-3-haiku-20240307-v1:0", 
        region_name="us-east-1"
    )
    llm.model_kwargs={'max_tokens_to_sample': 350}
    lex_agent=Agent(llm, chat.memory)
    
  
    message=lex_agent.invokeLLM_personal(question=prompt, context=customer_data)
    
    #Add AI response to chat
    chat.set_memory({'Assistant': message}, sessionId)
    
    print('Invoke agent personal response', message) 
    return message
       

#Handles personal question when identity is unverified
def personal_input_unverified(event, slots, intent, initial_user_message):
    print('Personal input unverified called')
    # Extract session attributes from the event
    session_attributes = event.get('sessionState', {}).get('sessionAttributes', {})
    identity_verified = session_attributes.get('identityVerified', False)
    customer_data = session_attributes.get('customerData', None)


    if event['invocationSource'] == 'DialogCodeHook':
        # Validate slots
        validation_result = validate_identity_slots(slots)
        
        if not validation_result['isValid']:
            # Respond to bot to elicit the invalid slot
            if 'message' in validation_result:
                
                #Clear Slots
                renewed_slots={'Pin': None, 'Username': None}
                
                print('Changed slots:', slots)
                response = {
                    'sessionState': {
                        'dialogAction': {
                            'slotToElicit': validation_result['invalidSlot'],
                            'type': 'ElicitSlot'
                        },
                        'intent': {
                            'name': intent,
                            'slots': slots
                        },
                        'sessionAttributes': {
                            'identityVerified': identity_verified,
                            'customerData': customer_data,
                            'initialUserMessage': initial_user_message
                        }
                    },
                    'messages': [
                        {
                            'contentType': 'PlainText',
                            'content': validation_result['message']
                        }
                    ]
                }
            else:
                response ={
                    'sessionState': {
                        'dialogAction':{
                            'slotToElicit': validation_result['invalidSlot'],
                            'type': 'ElicitSlot'
                        },
                        'intent':{
                            'name':intent,
                            'slots': slots
                        },
                        'sessionAttributes': {
                            'identityVerified': identity_verified,
                            'customerData': customer_data,
                            'initialUserMessage': initial_user_message
                        }
                    }
                }
        else:
            # Update session attributes with customer data
            identity_verified = True
            customer_data = validation_result.get('customerData', customer_data)
            print ('Customer data', customer_data)
            # Invoke Agent for personal questions with the initial user message
            result = invoke_agent_personal(initial_user_message, event['sessionId'], customer_data )

            # Prepare response with updated session attributes
            response = {
                'sessionState': {
                    'dialogAction': {
                        'type': 'Close'
                    },
                    'intent': {
                        'name': intent,
                        'slots': slots,
                        'state': 'Fulfilled'
                    },
                    'sessionAttributes': {
                        'identityVerified': identity_verified,
                        'customerData': json.dumps(customer_data)
                    }
                },
                'messages': [
                    {
                        'contentType': 'PlainText',
                        'content': result
                    }
                ]
            }
    
    return response
    
#Handles personal question when identity is verified
def personal_input_verified(event, slots, intent):
    print('Personal input verified called')
    if event['invocationSource']=='DialogCodeHook':
        #No need to validate slots
        user_message=event["inputTranscript"]
        session_attributes=event["sessionState"]["sessionAttributes"]
        customer_data=session_attributes['customerData']
        #Invoke Agent for Personal Questions
        result= invoke_agent_personal(user_message,event['sessionId'],customer_data)
        
        response={
            "sessionState":{
                "dialogAction": {
                    "type": "Close",
                },
                "intent": {
                    "name": intent, 
                    "slots": slots, 
                    "state": "Fulfilled"
                },
                "sessionAttributes": session_attributes,
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": result
                },
            ],
        }
            
    return response

#Validate loan application slots
def validate_application(slots):
    
   
    if not slots['LoanAmount']:
        print ('Validating Loan Amount slot')
        return{
            'isValid': False,
            'invalidSlot': 'LoanAmount'
        }
    if not slots['Debt']:
        
        print ('Validating Debt slot')
        return{
            'isValid': False,
            'invalidSlot': 'Debt'
        }
    if not slots['WorkHistory']:
    
        print ('Validating Work History slot')
        return{
            'isValid': False,
            'invalidSlot': 'WorkHistory'
        }

        
    if not slots['CoBorrower']:
  
        print ('Validating CoBorrower slot')
        return{
            'isValid': False,
            'invalidSlot': 'CoBorrower'
        }
  

    if not slots['DownPayment']:
  
        print ('Validating Down Payment slot')
        return{
            'isValid': False,
            'invalidSlot': 'DownPayment'
        }
    if not slots['HousingPayment']:
        print ('Validating Housing Payment slot')
        return{
            'isValid': False,
            'invalidSlot': 'HousingPayment'
        }
    if not slots['CreditScore']:
        print ('Validating Credit Score slot')
        return{
            'isValid': False,
            'invalidSlot': 'CreditScore'
        }
    if not slots['CloseDate']:
        print ('Validating Close Score slot')
        return{
            'isValid': False,
            'invalidSlot': 'CloseDate'
        }
    if not slots['MonthlyIncome']:
        print ('Validating Monthly Income slot')
        return{
            'isValid': False,
            'invalidSlot': 'MonthlyIncome'
        }
    return {'isValid': True}
    

#Handles loan application intent
def loan_application(event, slots, intent):

    if event['invocationSource']=='DialogCodeHook':
        #Validate Slots
        validation_result=validate_application(slots)
        
        if not validation_result['isValid']:
            #Send response to bot to elicit slot
            if 'message' in validation_result:
                response ={
                    'sessionState': {
                        'dialogAction':{
                            'slotToElicit': validation_result['invalidSlot'],
                            'type': 'ElicitSlot'
                        },
                        'intent':{
                            'name':intent,
                            'slots': slots
                        }
                    },
                    'messages':[
                        { 'contentType': 'PlainText',
                        'content': validation_result['message']
                        }
                    ]
                }
            else:
                #if results are valid delegate next action to bot
                 response ={
                    'sessionState': {
                        'dialogAction':{
                            'slotToElicit': validation_result['invalidSlot'],
                            'type': 'ElicitSlot'
                        },
                        'intent':{
                            'name':intent,
                            'slots': slots
                        }
                    }
                }
        else:
            #Send back to bot to delegate next action
            response = {
                'sessionState':{
                    'dialogAction':{
                        'type': 'Delegate'
                    },
                    'intent':{
                        'name': intent,
                        'slots': slots
                    }
                }
            }
        
      
        
                
            
    
    if event['invocationSource'] == 'FulfillmentCodeHook':
        #Business logic executed when all slots have been fufilled
        
        response = {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": intent,
                    "slots": slots,
                    "state": "Fulfilled"
                }

            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": "Your loan application is nearly complete. Please follow the link <url> to validate information and submit loan application!"
                }
            ]
        }
 
    
    
    print(response)
    return response
    
#Invokes bedrock powered langchain agent with user input that calls agent.run
def invoke_agent(prompt,sessionId):
    #Create Chat and add user's message
    chat=Chat({'Human': prompt}, sessionId)
    
    #Create LLM and Agent Object
    llm=BedrockChat(
        client=bedrock_client, 
        model_id="anthropic.claude-3-haiku-20240307-v1:0", 
        region_name="us-east-1"
    )
    llm.model_kwargs={'max_tokens_to_sample': 350}
    lex_agent=Agent(llm, chat.memory);
    
    message=lex_agent.run(input=prompt)
    
    #Add AI response to chat
    chat.set_memory({'Assistant': message}, sessionId)

    
    print("Invoke Agent result:", message)
    return message

    
#Handles fallback intent
def handle_fallback(event, slots, intent):
    
    if event['invocationSource']=='DialogCodeHook':
        #Get user message and session atttributes
        user_message=event["inputTranscript"]
        session_attributes=event["sessionState"]["sessionAttributes"]
        
        #Invoke Agent
        result= invoke_agent(user_message, event['sessionId'])
        
        response={
            "sessionState":{
                "dialogAction": {
                    "type": "Close",
                },
                "intent": {
                    "name": intent, 
                    "slots": slots, 
                    "state": "Fulfilled"
                },
                "sessionAttributes": session_attributes,
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": result
                },
            ],
        }
        
        print("Handle Fallback result:", response)
        return response
        
        
    
def lambda_handler(event, context):
    global identity_verified
    global initial_user_message
    global customerData
    
    slots=event['sessionState']['intent']['slots']
  
    intent=event['transcriptions'][0]['resolvedContext']['intent']
     
    print(event)
    print(slots)
    print(intent)
    print(event['invocationSource'])
    
    # Extract session attributes from the event
    session_attributes = event['sessionState']['sessionAttributes']
    print('Session Attributes', session_attributes)
    
    # Initialize variables
    identity_verified = session_attributes.get('identityVerified', False)
    customer_data = session_attributes.get('customerData', None)
    initial_user_message = session_attributes.get('initialUserMessage', "")

    
    #Route logic based on intent
    if intent=="LoanApplication":
        return loan_application(event, slots, intent)
    elif intent=="Identity":

        #If identity is unverified call personal_input_unverified
        if not identity_verified or identity_verified=='false':
            #Set intial user message
            if initial_user_message== "":
                initial_user_message=event["inputTranscript"]
                
            return personal_input_unverified(event,slots,intent, initial_user_message)
        else:
            #If identity is verified call personal_input_verified
            return personal_input_verified(event,slots,intent)
            
    else:
        return handle_fallback(event, slots, intent)
        

    


